﻿// vue.config.js
module.exports = {
  pluginOptions: {
    sourceDir: "client"
  },
  publicPath: "/app",
  outputDir: "wwwroot/app/",
  filenameHashing: false
}